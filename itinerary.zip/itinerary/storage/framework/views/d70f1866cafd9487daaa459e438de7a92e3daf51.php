<?php $__env->startSection('content'); ?>
	
<?php if(count($myideas) > 0): ?>

<table>
    <thead>
		<tr>
			<td>Title</td>
			<td>Publisher</td>
			<td>Destination</td>
			<td>Start_Date</td>
			<td>End_Date</td>
			<td>Tags</td>
			<td>Comments</td>
			<td>Actions</td>
		</tr>
    </thead>
    <tbody id="idea-results">
		<?php $__currentLoopData = $myideas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><a href="<?php echo e(route('ideas.show', $idea->id)); ?>"><?php echo e($idea->title); ?></a></td>
			<td><?php echo e($idea->publisher); ?></td>
			<td><?php echo e($idea->destination); ?></td>
			<td><?php echo e($idea->start_date); ?></td>
			<td><?php echo e($idea->end_date); ?></td>
			<td><?php echo e($idea->tags); ?></td>
			<td><?php echo e($idea->comments_number); ?></td>
			<td><a href="/ideas/<?php echo e($idea->id); ?>/edit" class="btn btn-info">Edit</a> </td>
			<td>
				<?php echo Form::open(['action' => ['IdeasController@destroy', $idea->id], 'method' => 'DELETE']); ?>

					<?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>

				<?php echo Form::close(); ?>

			</td>
      </tr>
	  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php else: ?>

<p>There is no any idea currently. Go create one!</p>

<?php endif; ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('crudlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /Applications/XAMPP/xamppfiles/htdocs/travel/resources/views/ideas/myidea.blade.php */ ?>