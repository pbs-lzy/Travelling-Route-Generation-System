<?php $__env->startSection('content'); ?>
<p>Please use the form below to edit your idea.</p>
<?php echo Form::open(['action' => ['IdeasController@update', $idea->id], 'method' => 'PUT']); ?>


<div class="form-group">
    <?php echo Form::label('title', 'Title'); ?>

    <?php echo Form::text('title', $idea->title, ['class' => 'form-control']); ?>

</div>

<div class="form-group">
    <?php echo Form::label('destination', 'Destination'); ?>

    <?php echo Form::text('destination', $idea->destination, ['class' => 'form-control']); ?>

</div>

<div class="form-group">
    <?php echo Form::label('start_date', 'Start Date'); ?>

    <?php echo Form::text('start_date', $idea->start_date, ['class' => 'form-control datepicker']); ?>

</div>

<div class="form-group">
    <?php echo Form::label('end_date', 'End Date'); ?>

    <?php echo Form::text('end_date', $idea->end_date, ['class' => 'form-control datepicker']); ?>

</div>

<div class="form-group">
    <?php echo Form::label('tags', 'Tags'); ?>

    <?php echo Form::text('tags', $idea->tags, ['class' => 'form-control']); ?>

</div>

<?php echo Form::submit('Submit', ['class' => 'btn btn-info']); ?>


<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('crudlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /Applications/XAMPP/xamppfiles/htdocs/travel/resources/views/ideas/edit.blade.php */ ?>