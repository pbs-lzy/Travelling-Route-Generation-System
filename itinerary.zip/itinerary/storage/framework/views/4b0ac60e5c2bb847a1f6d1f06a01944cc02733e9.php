<?php $__env->startSection('content'); ?>
    <h2><?php echo e($idea->title); ?></h2>
    <p>Destination: <span id="dest"><?php echo e($idea->destination); ?></span></p>
    <p>Travel Date: <?php echo e($idea->start_date); ?> to <?php echo e($idea->end_date); ?></p>
    <p>Tags: <?php echo e($idea->tags); ?></p>
    <p>Publisher: <?php echo e($idea->publisher); ?></p>
    
    <section>
        <p>Total <span id="comments_number"><?php echo e($idea->comments_number); ?></span> comment(s)</p>
        <div id="chatbox"></div>
        <input id="comments_content" />
        <input id="sendcomment" type="submit" value="Send" />
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('API'); ?>
    <h2>Destination Weather</h2>
    <p id="destination_weather">Oops, we can not find the destination.</p>
    <h2>Hotwire Hotel Search</h2>
    <p id="testa"></p>
    <ol id="hotel_list"></ol>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('commentlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /Applications/XAMPP/xamppfiles/htdocs/travel/resources/views/ideas/show.blade.php */ ?>