<!DOCTYPE html>
<html lang="en">

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="Find easily a traveling route">
	<meta name="author" content="Ansonika">
	<title>Route Generation</title>

	<!-- Favicons-->
	<link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
	<link rel="apple-touch-icon" type="image/x-icon" href="img/apple-touch-icon-57x57-precomposed.png">
	<link rel="apple-touch-icon" type="image/x-icon" sizes="72x72" href="img/apple-touch-icon-72x72-precomposed.png">
	<link rel="apple-touch-icon" type="image/x-icon" sizes="114x114" href="img/apple-touch-icon-114x114-precomposed.png">
	<link rel="apple-touch-icon" type="image/x-icon" sizes="144x144" href="img/apple-touch-icon-144x144-precomposed.png">

	<!-- BASE CSS -->
	<link href="css/yong/bootstrap.min.css" rel="stylesheet">
	<link href="css/yong/yongstyle.css" rel="stylesheet">
	<link href="css/yi/yistyle.css" rel="stylesheet">
	<link href="css/yong/menu.css" rel="stylesheet">
	<link href="css/yong/vendors.css" rel="stylesheet">
	<link href="css/yong/icon_fonts/css/all_icons_min.css" rel="stylesheet">

	<!-- SPECIFIC CSS -->
	<link href="css/yong/tables.css" rel="stylesheet">
    
	<!-- YOUR CUSTOM CSS -->
	<link href="css/yong/custom.css" rel="stylesheet">
	
	<!-- Modernizr -->
	<script src="js/yong/modernizr_tables.js"></script>
	
    <style>
        html,
        body {
            height: 100%;
        }
		.search_bar_wrapper{
			background:#172f46;
		}
		.search_bar_wrapper:hover{
			cursor:hand;
			background:#e74e84;
		}
		.list_title{
			background:white;
		}
    </style>

</head>

<body>

	<nav class="gtco-nav" role="navigation" style="background-color: #172f46;">
		<div class="gtco-container">
			
			<div class="row">
				<div class="col-sm-4 col-xs-12">
					<div id="gtco-logo"><a href="/index">I<em>.</em>YOU </a></div>
				</div>
				<div class="col-xs-8 text-right menu-1">
					
				</div>
			</div>
			
		</div>
	</nav>


	<div class="layer"></div>
	<!-- Mobile menu overlay mask -->

	<div id="preloader">
		<div data-loader="circle-side"></div>
	</div>
	<!-- End Preload -->

	<!-- /Header -->

	<div class="container-fluid full-height">
		<div class="row row-height">
			<div class="col-lg-3 content-left" id="daylist" style="padding-top:0px;background-color: #172f46;">
			<!-- /margin_60_35 -->
			
					
					
					<!-- /filters -->
			</div>
			<script>
				var multilinedata = `<?php echo $output; ?>`;
				var arrdata = multilinedata.split('\n');
				var startenddata = arrdata[0].split('|');
				var departureCity = startenddata[0];
				var arrivalCity = startenddata[1];
				var citydata = arrdata[1].split('|');
				var playdaydata = arrdata[2].split('|');
				var total_play_day = 0;
				var cities = new Array(total_play_day);
				for (var i = 0; i < playdaydata.length; i++) {
					total_play_day += parseInt(playdaydata[i]);
					var city = Array(parseInt(playdaydata[i])).fill(citydata[i]);
					cities = cities.concat(city);
				};

				var day = new Array(total_play_day);
				for (var i = 0; i < total_play_day; i++) {
					day[i] = new Array(5);
					day[i][0] = cities[i];
					daydetailsarr = arrdata[i+3].split('&');
					titles = daydetailsarr[0].split('|');
					times = daydetailsarr[1].split('|');
					longitudes = daydetailsarr[2].split('|');
					latitudes = daydetailsarr[3].split('|');
					day[i][1] = titles;
					day[i][2] = times;
					day[i][3] = longitudes;
					day[i][4] = latitudes;
				};





				
				var html="";
				var oldcity = departureCity;
				for(i=0; i<day.length; i++){
					if (oldcity == day[i][0]) {
						html+="<div class='search_bar_wrapper'><div class='search_bar_list'><div class='strip_list' style='margin-bottom:0px; height:107px;'><figure><a href='javascript:void(0)' onclick='map(\""+(i+1)+"\",\""+day[i][0]+"\","+"day["+i+"][1]"+","+"day["+i+"][2]"+","+"day["+i+"][3],"+"day["+i+"][4])'><img src='img/d"+(i+1)+".png' alt=''></a></figure><h3>"+day[i][0]+"</h3><br></div></div></div>";
					} else {
						html+="<div class='search_bar_wrapper'><div class='search_bar_list'><div class='strip_list' style='margin-bottom:0px; height:107px;'><figure><a href='javascript:void(0)' onclick='map(\""+(i+1)+"\",\""+day[i][0]+"\","+"day["+i+"][1]"+","+"day["+i+"][2]"+","+"day["+i+"][3],"+"day["+i+"][4])'><img src='img/d"+(i+1)+".png' alt=''></a></figure><h3>"+oldcity+"->"+day[i][0]+"</h3><br></div></div></div>";
						oldcity = day[i][0];
					}
					//html+="<div class='search_bar_wrapper'><div class='search_bar_list'><div class='strip_list' style='margin-bottom:0px; height:107px;'><figure><a href='javascript:void(0)' onclick='map(\""+(i+1)+"\",\""+day[i][0]+"\","+"day["+i+"][1]"+","+"day["+i+"][2]"+","+"day["+i+"][3],"+"day["+i+"][4])'><img src='img/d"+(i+1)+".png' alt=''></a></figure><h3>"+day[i][0]+"</h3><br></div></div></div>";
					// html+="<div class='search_bar_wrapper'><div class='search_bar_list'><div class='strip_list' style='margin-bottom:0px; height:107px;'><figure><a href='javascript:void(0)' onclick='map(\""+departureCity+"\",\""+arrivalCity+"\",\""+(i+1)+"\",\""+day[i][0]+"\","+"day["+i+"][1]"+","+"day["+i+"][2]"+","+"day["+i+"][3],"+"day["+i+"][4])'><img src='img/d"+(i+1)+".png' alt=''></a></figure><h3>"+day[i][0]+"</h3><br></div></div></div>";
				};

				var daylist=document.getElementById("daylist");
				var temp=daylist.innerHTML;
				daylist.innerHTML=temp+html;


				// var city="南京";
				// var titles=new Array("南京金汇大酒店","红山森林动物园","玄武湖","中山陵景区");
				// var longitude=new Array("118.794644","118.80525812089361","118.79930925614538","118.84760955880598");
				// var latitude=new Array("32.027227","32.10212389126866","32.08041701905591","32.05287694557689");
				// var time=new Array("0","3","4","4");
				
				// var city2="南京";
				// var titles2=new Array("南京金汇大酒店","秦淮河画舫","夫子庙秦淮河风光带","瞻园","南京总统府","侵华日军南京大屠杀遇难同胞纪念馆");
				// var longitude2=new Array("118.794644","118.79521999339607","118.79523536699658","118.79171149414205","118.75147800730005","118.8039743524893");
				// var latitude2=new Array("32.027227","32.027081718573854","32.02774395091252","32.02664641893529","32.040613954051466","32.04903823294875");
				// var time2=new Array("0","1","2","2","2","3");
				// var day=new Array();
				// var len=2;
				// var html="";
				// day[0]=[city,titles,time,longitude,latitude];
				// day[1]=[city2,titles2,time2,longitude2,latitude2];
				
				// for(i=0;i<day.length;i++){
					
				// 	html+="<div class='search_bar_wrapper'><div class='search_bar_list'><div class='strip_list' style='margin-bottom:0px; height:107px;'><figure><a href='javascript:void(0)' onclick='map(\""+(i+1)+"\",\""+day[i][0]+"\","+"day["+i+"][1]"+","+"day["+i+"][2]"+","+"day["+i+"][3],"+"day["+i+"][4])'><img src='img/d"+(i+1)+".png' alt=''></a></figure><h3>"+i+"</h3><br>"+day[i][0]+"</div></div></div>";
				// }
				// var daylist=document.getElementById("daylist");
				// var temp=daylist.innerHTML;
				// daylist.innerHTML=temp+html;
			</script>
			<!-- /content-left-->
		
			<div class="col-lg-5 content-left" id="listdiv" style="padding-top:0px;">
				<div id="d1" class="list_home" style="display: none;">
                            <div class="list_title">
                                
                                <h3>23/6</h3>
								<br>
									南京
								<br>
                            </div>
                            <ul>
                                <li><a href=""><strong>酒店</strong>南京金汇大酒店</a></li>
								<li><a href=""><strong>Taxi</strong>3.69km  14min</a></li>
								<li><a href=""><strong>1</strong>秦淮河画舫</a></li>
								<li><a href=""><strong>2</strong>夫子庙秦淮河风光带</a></li>
								<li><a href=""><strong>Taxi</strong>6.72km  25min</a></li>
								<li><a href=""><strong>3</strong>瞻园</a></li>
								<li><a href=""><strong>Taxi</strong>6.72km  25min</a></li>
								<li><a href=""><strong>4</strong>南京总统府</a></li>
								<li><a href=""><strong>Taxi</strong>6.72km  25min</a></li>
								<li><a href=""><strong>5</strong>侵华日军南京大屠杀遇难同胞纪念馆</a></li>
								<li><a href=""><strong>Taxi</strong>6.72km  25min</a></li>
								<li><a href=""><strong>酒店</strong>南京金汇大酒店</a></li>
							
                            </ul>
                </div>
				<div id="d2" class="list_home" style="display: none;">
                            <div class="list_title">
                                
                                <h3>24/6</h3>
								<br>
									南京
								<br>
                            </div>
                            <ul>
                                <li><a href=""><strong>酒店</strong>南京金汇大酒店</a></li>
								<li><a href=""><strong>Taxi</strong>3.69km  14min</a></li>
								<li><a href=""><strong>1</strong>红山森林动物园</a></li>
								<li><a href=""><strong>Taxi</strong>14.28km  30min</a></li>
								<li><a href=""><strong>2</strong>玄武湖</a></li>
								<li><a href=""><strong>Taxi</strong>6.72km  25min</a></li>
								<li><a href=""><strong>3</strong>中山陵景区</a></li>
								
								<li><a href=""><strong>酒店</strong>南京金汇大酒店</a></li>
							
                            </ul>
                </div>
				<div id="d3" class="list_home" style="display: none;">
                            <div class="list_title">
                                
                                <h3>25/6</h3>
								<br>
									杭州
								<br>
                            </div>
                            <ul>
                                <li><a href=""><strong>酒店</strong>杭州JW万豪酒店</a></li>
								<li><a href=""><strong>Taxi</strong>3.69km  14min</a></li>
								<li><a href=""><strong>1</strong>灵隐寺</a></li>
								<li><a href=""><strong>Taxi</strong>14.28km  30min</a></li>
								<li><a href=""><strong>2</strong>杭州动物园</a></li>
								<li><a href=""><strong>Taxi</strong>6.72km  25min</a></li>
								<li><a href=""><strong>3</strong>杭州宋城景区</a></li>
								<li><a href=""><strong>酒店</strong>杭州JW万豪酒店</a></li>
							
                            </ul>
                </div>
			</div>
			
			<div class="col-lg-4" style="background: #172f46;">
				<div id="map_listing"></div>
				<!-- map-->
			</div>
			<!-- /map-right-->
			
		</div>
		<!-- /row-->
	</div>
	<!-- /container-fluid -->

	<!-- COMMON SCRIPTS -->
	<script src="js/yong/jquery-2.2.4.min.js"></script>
	<script src="js/yong/common_scripts.min.js"></script>
	<script src="assets/validate.js"></script>
	<script src="js/yong/functions.js"></script>
    
    <!-- SPECIFIC SCRIPTS -->
    
    <script src="http://libs.baidu.com/jquery/1.9.0/jquery.js"></script>
    <!--<script src="http://maps.googleapis.com/maps/api/js?key=AIzaSyCvI1uy8W1WWeK5Or8Qq47QCPQX94dprXE&callback=initMap" async defer></script>
	<script src="js/yong/map_listingv2.js"></script>-->
	<script type="text/javascript" src="http://api.map.baidu.com/api?v=3.0&ak=tdOqYSMs77Arf9FAV6AA2yX3FGBUk45y&callback=initMap"></script>
	<script src="js/yong/map.js"></script>
    <script src="js/yong/infobox.js"></script> 
    <script src="js/yong/jquery.selectbox-0.2.js"></script>
	<script>
		$(".selectbox").selectbox();
		window.onload = function() {
			document.querySelector("#daylist a:first-child").onclick();
		};
	</script>
</body>

</html>
<?php /* /Applications/XAMPP/xamppfiles/htdocs/itinerary/resources/views/routes/result.blade.php */ ?>