<?php $__env->startSection('content'); ?>
<p>Please use the form below to add your idea.</p>
<?php echo Form::open(['route' => 'ideas.store']); ?>


<div class="form-group">
    <?php echo Form::label('title', 'Title'); ?>

    <?php echo Form::text('title', null, ['class' => 'form-control', 'placeholder' => 'Title']); ?>

</div>

<div class="form-group">
    <?php echo Form::label('destination', 'Destination'); ?>

    <?php echo Form::text('destination', null, ['class' => 'form-control', 'placeholder' => 'Destination']); ?>

</div>

<div class="form-group">
    <?php echo Form::label('start_date', 'Start Date'); ?>

    <?php echo Form::text('start_date', null, ['class' => 'form-control datepicker', 'placeholder' => 'Start Date']); ?>

</div>

<div class="form-group">
    <?php echo Form::label('end_date', 'End Date'); ?>

    <?php echo Form::text('end_date', null, ['class' => 'form-control datepicker', 'placeholder' => 'End Date']); ?>

</div>

<div class="form-group">
    <?php echo Form::label('tags', 'Tags'); ?>

    <?php echo Form::text('tags', null, ['class' => 'form-control', 'placeholder' => 'Tags']); ?>

</div>

<?php echo Form::submit('Submit', ['class' => 'btn btn-info']); ?>


<?php echo Form::close(); ?>

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('crudlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /Applications/XAMPP/xamppfiles/htdocs/travel/resources/views/ideas/create.blade.php */ ?>