<?php $__env->startSection('content'); ?>

<?php if(count($ideas) > 0): ?>
<table>
    <thead>
		<tr>
			<td>Title</td>
			<td>Publisher</td>
			<td>Destination</td>
			<td>Start_Date</td>
			<td>End_Date</td>
			<td>Tags</td>
			<td>Comments</td>
		</tr>
    </thead>
    <tbody id="idea-results">
      <?php $__currentLoopData = $ideas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
          <td><a href="<?php echo e(route('ideas.show',$idea->id)); ?>"><?php echo e($idea->title); ?></a></td>
          <td><?php echo e($idea->publisher); ?></td>
          <td><?php echo e($idea->destination); ?></td>
          <td><?php echo e($idea->start_date); ?></td>
		  <td><?php echo e($idea->end_date); ?></td>
		  <td><?php echo e($idea->tags); ?></td>
          <td><?php echo e($idea->comments_number); ?></td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<p id="summary"></p>

<?php else: ?>

<p>There is no any idea currently. Go create one!</p>

<?php endif; ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('search'); ?>

<select id="searchselect">
	<option>Destination</option>
	<option>Tag</option>
</select>
<input type="text" id="searchkeyword" name="search" />
<span>
	<input type="checkbox" id="partial" name="partial" />
	<span>Partial Match</span>
</span>
<input type="submit" id="submitsearch" value="Find Ideas!" />

<?php $__env->stopSection(); ?>






<?php echo $__env->make('mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /Applications/XAMPP/xamppfiles/htdocs/travel/resources/views/ideas/index.blade.php */ ?>