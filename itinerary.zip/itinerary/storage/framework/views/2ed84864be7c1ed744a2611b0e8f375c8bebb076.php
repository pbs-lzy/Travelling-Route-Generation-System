<!DOCTYPE html>
<html>
<head>
	<title>try</title>
</head>
<body>

</body>


<script>
    var multilinedata = `<?php echo $output; ?>`;
    var arrdata = multilinedata.split(' ');
    var citydata = arrdata[0].split('|');
    var playdaydata = arrdata[1].split('|');
    var total_play_day = 0;
    var cities = new Array(total_play_day);
    for (var i = 0; i < playdaydata.length; i++) {
        total_play_day += parseInt(playdaydata[i]);
        var city = Array(parseInt(playdaydata[i])).fill(citydata[i]);
        cities = cities.concat(city);
    };

    var days = new Array(total_play_day);
    for (var i = 0; i < total_play_day; i++) {
        days[i] = new Array(5);
        days[i][0] = cities[i];
        daydetailsarr = arrdata[i+2].split('&');
        titles = daydetailsarr[0].split('|');
        times = daydetailsarr[1].split('|');
        longitudes = daydetailsarr[2].split('|');
        latitudes = daydetailsarr[3].split('|');
        days[i][1] = titles;
        days[i][2] = times;
        days[i][3] = longitudes;
        days[i][4] = latitudes;
    };








</script>
</html>


<?php /* /Applications/XAMPP/xamppfiles/htdocs/itinerary/resources/views/routes/callpy.blade.php */ ?>