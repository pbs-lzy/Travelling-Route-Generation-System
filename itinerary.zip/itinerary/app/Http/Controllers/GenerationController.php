<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DateTime;

class GenerationController extends Controller
{
    public function index()
    {
        return view('ideas.index');
    }

    public function generate(Request $request) {
        $request->validate([
            'destination-form1' => 'required',
            'date-start' => 'required|date',
            'date-end' => 'required|date|after:date-start',
            'place-start' => 'required',
            'place-arrive' => 'required'
        ]);

        $date_a = $request->get('date-end');
        $date_a = strtotime($date_a);
        $date_b = $request->get('date-start');
        $date_b = strtotime($date_b);

        $diff = $date_a - $date_b;
        $total_day = round($diff / (60 * 60 * 24));

        $hotelLuxury = $request->get('hotel-type');
        $schedulingType = $request->get('scheduling-type');

        $arguments = $request->get('place-start') . " " . $request->get('place-arrive'). " ". $total_day. " " . $hotelLuxury ." ". 
        $schedulingType. " ". $request->get('destination-form1') . " " . $request->get('destination-form2') . " " . $request->get('destination-form3');
        $commandstr = 'python3 /Users/lauzingai/Desktop/Travelling-Route-Generation-System/TravelPlace/ItineraryGenerator.py ' . $arguments;
        $command = escapeshellcmd($commandstr);
        $output = shell_exec($command);
        return view('routes.result', compact('output'));
    }

    public function testcallpy() {

    }
}
