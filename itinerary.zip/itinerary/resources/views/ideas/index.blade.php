<!DOCTYPE HTML>

<html>
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>IYOU</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Free HTML5 Website Template by FreeHTML5.co" />
	<meta name="keywords" content="free website templates, free html5, free template, free bootstrap, free website template, html5, css3, mobile first, responsive" />
	<meta name="author" content="FreeHTML5.co" />

  	<!-- Facebook and Twitter integration -->
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />

	<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700" rel="stylesheet">
	
	<!-- Animate.css -->
	{{-- <link href="{{ asset('css/yi/animate.css') }}" rel="stylesheet" > --}}
	<link rel="stylesheet" href="css/yi/animate.css">
	<!-- Icomoon Icon Fonts-->
	{{-- <link href="{{ asset('css/yi/icomoon.css') }}" rel="stylesheet" > --}}
	<link rel="stylesheet" href="css/yi/icomoon.css">
	<!-- Themify Icons-->
	{{-- <link href="{{ asset('css/yi/themify-icons.css') }}" rel="stylesheet" > --}}
	<link rel="stylesheet" href="css/yi/themify-icons.css">
	<!-- Bootstrap  -->
	{{-- <link href="{{ asset('css/yi/bootstrap.css') }}" rel="stylesheet" > --}}
	<link rel="stylesheet" href="css/yi/bootstrap.css">
	<!-- Magnific Popup -->
	{{-- <link href="{{ asset('css/yi/magnific-popup.css') }}" rel="stylesheet" > --}}
	<link rel="stylesheet" href="css/yi/magnific-popup.css">

	<!-- Magnific Popup -->
	{{-- <link href="{{ asset('css/yi/bootstrap-datepicker.min.css') }}" rel="stylesheet" > --}}
	<link rel="stylesheet" href="css/yi/bootstrap-datepicker.min.css">

	<!-- Owl Carousel  -->
	{{-- <link href="{{ asset('css/yi/owl.carousel.min.css') }}" rel="stylesheet" > --}}
	<link rel="stylesheet" href="css/yi/owl.carousel.min.css">
	{{-- <link href="{{ asset('css/yi/owl.theme.default.min.css') }}" rel="stylesheet" > --}}
	<link rel="stylesheet" href="css/yi/owl.theme.default.min.css">

	<!-- Theme style  -->
	{{-- <link href="{{ asset('css/yi/style.css') }}" rel="stylesheet" > --}}
	<link rel="stylesheet" href="css/yi/yistyle.css">

	<!-- Form style  -->
	<link href="{{ asset('css/yi/layout.css') }}" rel="stylesheet" >

	<!-- Modernizr JS -->
	{{-- <script type="text/javascript" src="{{ asset('js/yi/modernizr-2.6.2.min.js') }}"></script> --}}
	<script src="js/yi/modernizr-2.6.2.min.js"></script>

	<!-- Form JS -->
	<script type="text/javascript" src="{{ asset('js/yi/updatecomment.js') }}"></script>


	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/yi/respond.min.js"></script>
	<![endif]-->

	</head>
	<body>
		
	<div class="gtco-loader"></div>
	
	<div id="page">

	
	<!-- <div class="page-inner"> -->
	<nav class="gtco-nav" role="navigation">
		<div class="gtco-container">
			
			<div class="row">
				<div class="col-sm-4 col-xs-12">
					<div id="gtco-logo"><a href="/index">I<em>.</em>YOU </a></div>
				</div>
				<div class="col-xs-8 text-right menu-1">
					{{-- <ul>
						<li><a href="destination.html">Destination</a></li>
						<li class="has-dropdown">
							<a href="#">Travel</a>
							<ul class="dropdown">
								<li><a href="#">Europe</a></li>
								<li><a href="#">Asia</a></li>
								<li><a href="#">America</a></li>
								<li><a href="#">Canada</a></li>
							</ul>
						</li>
						<li><a href="pricing.html">Pricing</a></li>
						<li><a href="contact.html">Contact</a></li>
					</ul>	 --}}
				</div>
			</div>
			
		</div>
	</nav>
	
	<header id="gtco-header" class="gtco-cover gtco-cover-md" role="banner" style="background-image: url(img/img_bg_2.jpg)">
		<div class="overlay"></div>
		<div class="gtco-container">
			<div class="row">
				<div class="col-md-12 col-md-offset-0 text-left">
					

					<div class="row row-mt-15em">
						<div class="col-md-7 mt-text animate-box" data-animate-effect="fadeInUp">
							<h1>Planning Trip To Anywhere in China ?</h1>	
						</div>
						<div class="col-md-4 col-md-push-1 animate-box" data-animate-effect="fadeInRight">
							<div class="form-wrap">
								<div class="tab">
									
									<div class="tab-content">
										<div class="tab-content-inner active" data-content="signup">
											<h3>Your Trip</h3>
											<form action="/result" method="post">
												@csrf
												<div class="row form-group">
													<div id="destinations-form" class="form-group col-md-12" style="margin-bottom: 0px;">
														<label id="destination-form-label" for="destination-form" style="display:block;">Destination</label>
														<input id="destination-form1" type="text" class="form-control col-md-4 input-destination" name="destination-form1"/>
													</div>
													<div class="col-md-12">
														<a id="add-destination-btn" class="addDestinationBtn">+</a>
													</div>
												</div>
												
												<div class="row form-group">
													<div class="col-md-6">
														<label id="date-start-label" for="date-start">Departure Date</label>
														<input type="text" id="date-start" class="form-control initialized2" name="date-start">
													</div>

													<div class="col-md-6">
														<label id="date-end-label" for="date-end">Arrival Date</label>
														<input type="text" id="date-end" class="form-control initialized2" name="date-end">
													</div>
												</div>

												<div class="row form-group">
													<div class="col-md-6">
														<label id="place-start-label" for="place-start">Departure Place</label>
														<input id="place-start" type="text" class="form-control initialized2" name="place-start">
													</div>

													<div class="col-md-6">
														<label id="place-arrive-label" for="place-arrive">Arrival Place</label>
														<input type="text" id="place-arrive" class="form-control initialized2" name="place-arrive">
													</div>
												</div>

												<div class="row form-group">
													<div class="col-md-6">
														<label id="hotel-type-label" for="hotel-type">Hotel Luxury</label>
														<select name="hotel-type" id="hotel-type" class="form-control initialized2">
															<option value="Economic">Economic</option>
															<option value="Normal">Normal</option>
															<option value="Luxury">Luxury</option>
														</select>
													</div>

													<div class="col-md-6">
														<label id="scheduling-type-label" for="scheduling-type">Scheduling Type</label>
														<select name="scheduling-type" id="scheduling-type" class="form-control initialized2">
															<option value="Loose">Loose</option>
															<option value="Moderate">Moderate</option>
															<option value="Compact">Compact</option>
														</select>
													</div>
												</div>

												<div class="row form-group">
													<div class="col-md-12">
														<button type="submit" id="btn-submit" class="btn btn-primary btn-block">Submit</button>
													</div>
												</div>
											</form>	
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
							
					
				</div>
			</div>
		</div>
	</header>

	<style>
	.under {
		display: none;
	}
	#centereddiv {
		position: fixed;
		z-index: 1000;
		width: auto;
		top: 50%;
		left: 50%;
		height: 60%;
		transform: translate(-50%, -50%);
	}
	.overlay1 {
		z-index: 999;
		position: absolute;
		top: 0;
		left: 0;
		right: 0;
		bottom: 0;
		background: rgba(0,0,0,.85);
	}
	</style>
	<div class="under">
		<div class="overlay1"></div>
		<img id="centereddiv" src="/img/loading.gif"/>
	</div>
	
	{{-- <div class="gtco-section">
		<div class="gtco-container">
			<div class="row">
				<div class="col-md-8 col-md-offset-2 text-center gtco-heading">
					<h2>Most Popular Destination</h2>
					<p></p>
				</div>
			</div>
			<div class="row">

				<div class="col-lg-4 col-md-4 col-sm-6">
					<a href="img/img_1.jpg" class="fh5co-card-item image-popup">
						<figure>
							<div class="overlay"><i class="ti-plus"></i></div>
							<img src="img/img_1.jpg" alt="Image" class="img-responsive">
						</figure>
						<div class="fh5co-text">
							<h2>New York, USA</h2>
							<p>Far far away, behind the word mountains, far from the countries Vokalia..</p>
							<p><span class="btn btn-primary">Schedule a Trip</span></p>
						</div>
					</a>
				</div>
				<div class="col-lg-4 col-md-4 col-sm-6">
					<a href="img/img_2.jpg" class="fh5co-card-item image-popup">
						<figure>
							<div class="overlay"><i class="ti-plus"></i></div>
							<img src="img/img_2.jpg" alt="Image" class="img-responsive">
						</figure>
						<div class="fh5co-text">
							<h2>Seoul, South Korea</h2>
							<p>Far far away, behind the word mountains, far from the countries Vokalia..</p>
							<p><span class="btn btn-primary">Schedule a Trip</span></p>
						</div>
					</a>
				</div>
				<div class="col-lg-4 col-md-4 col-sm-6">
					<a href="img/img_3.jpg" class="fh5co-card-item image-popup">
						<figure>
							<div class="overlay"><i class="ti-plus"></i></div>
							<img src="img/img_3.jpg" alt="Image" class="img-responsive">
						</figure>
						<div class="fh5co-text">
							<h2>Paris, France</h2>
							<p>Far far away, behind the word mountains, far from the countries Vokalia..</p>
							<p><span class="btn btn-primary">Schedule a Trip</span></p>
						</div>
					</a>
				</div>


				<div class="col-lg-4 col-md-4 col-sm-6">
					<a href="img/img_4.jpg" class="fh5co-card-item image-popup">
						<figure>
							<div class="overlay"><i class="ti-plus"></i></div>
							<img src="img/img_4.jpg" alt="Image" class="img-responsive">
						</figure>
						<div class="fh5co-text">
							<h2>Sydney, Australia</h2>
							<p>Far far away, behind the word mountains, far from the countries Vokalia..</p>
							<p><span class="btn btn-primary">Schedule a Trip</span></p>
						</div>
					</a>
				</div>

				<div class="col-lg-4 col-md-4 col-sm-6">
					<a href="img/img_5.jpg" class="fh5co-card-item image-popup">
						<figure>
							<div class="overlay"><i class="ti-plus"></i></div>
							<img src="img/img_5.jpg" alt="Image" class="img-responsive">
						</figure>
						<div class="fh5co-text">
							<h2>Greece, Europe</h2>
							<p>Far far away, behind the word mountains, far from the countries Vokalia..</p>
							<p><span class="btn btn-primary">Schedule a Trip</span></p>
						</div>
					</a>
				</div>

				<div class="col-lg-4 col-md-4 col-sm-6">
					<a href="img/img_6.jpg" class="fh5co-card-item image-popup">
						<figure>
							<div class="overlay"><i class="ti-plus"></i></div>
							<img src="img/img_6.jpg" alt="Image" class="img-responsive">
						</figure>
						<div class="fh5co-text">
							<h2>Spain, Europe</h2>
							<p>Far far away, behind the word mountains, far from the countries Vokalia..</p>
							<p><span class="btn btn-primary">Schedule a Trip</span></p>
						</div>
					</a>
				</div>

			</div>
		</div>
	</div> --}}
	
	{{-- <div id="gtco-features">
		<div class="gtco-container">
			<div class="row">
				<div class="col-md-8 col-md-offset-2 text-center gtco-heading animate-box">
					<h2>How It Works</h2>
					<p>Dignissimos asperiores vitae velit veniam totam fuga molestias accusamus alias autem provident. Odit ab aliquam dolor eius.</p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-4 col-sm-6">
					<div class="feature-center animate-box" data-animate-effect="fadeIn">
						<span class="icon">
							<i>1</i>
						</span>
						<h3>Lorem ipsum dolor sit amet</h3>
						<p>Dignissimos asperiores vitae velit veniam totam fuga molestias accusamus alias autem provident. Odit ab aliquam dolor eius.</p>
					</div>
				</div>
				<div class="col-md-4 col-sm-6">
					<div class="feature-center animate-box" data-animate-effect="fadeIn">
						<span class="icon">
							<i>2</i>
						</span>
						<h3>Consectetur adipisicing elit</h3>
						<p>Dignissimos asperiores vitae velit veniam totam fuga molestias accusamus alias autem provident. Odit ab aliquam dolor eius.</p>
					</div>
				</div>
				<div class="col-md-4 col-sm-6">
					<div class="feature-center animate-box" data-animate-effect="fadeIn">
						<span class="icon">
							<i>3</i>
						</span>
						<h3>Dignissimos asperiores vitae</h3>
						<p>Dignissimos asperiores vitae velit veniam totam fuga molestias accusamus alias autem provident. Odit ab aliquam dolor eius.</p>
					</div>
				</div>
				

			</div>
		</div>
	</div> --}}

	<div id="gtco-counter" class="gtco-section">
		<div class="gtco-container">

			<div class="row">
				<div class="col-md-8 col-md-offset-2 text-center gtco-heading animate-box">
					<h2>Achievement</h2>
					<p></p>
				</div>
			</div>

			<div class="row">
				
				<div class="col-md-4 col-sm-8 animate-box" data-animate-effect="fadeInUp">
					<div class="feature-center">
						<span class="counter js-counter" data-from="0" data-to="1843" data-speed="5000" data-refresh-interval="50">1</span>
						<span class="counter-label">Destination</span>
					</div>
				</div>
				<div class="col-md-4 col-sm-8 animate-box" data-animate-effect="fadeInUp">
					<div class="feature-center">
						<span class="counter js-counter" data-from="0" data-to="5529" data-speed="5000" data-refresh-interval="50">1</span>
						<span class="counter-label">Hotels</span>
					</div>
				</div>
				{{-- <div class="col-md-3 col-sm-6 animate-box" data-animate-effect="fadeInUp">
					<div class="feature-center">
						<span class="counter js-counter" data-from="0" data-to="12402" data-speed="5000" data-refresh-interval="50">1</span>
						<span class="counter-label">Citys</span>
					</div>
				</div> --}}
				<div class="col-md-4 col-sm-8 animate-box" data-animate-effect="fadeInUp">
					<div class="feature-center">
						<span class="counter js-counter" data-from="0" data-to="25000" data-speed="5000" data-refresh-interval="50">1</span>
						<span class="counter-label">Spots</span>
					</div>
				</div>
					
			</div>
		</div>
	</div>


	<div class="gtco-cover gtco-cover-sm" style="background-image: url(img/img_bg_1.jpg)"  data-stellar-background-ratio="0.5">
		<div class="overlay"></div>
		<div class="gtco-container text-center">
			<div class="display-t">
				<div class="display-tc">
					<h1>We have high quality services that you will surely love!</h1>
				</div>	
			</div>
		</div>
	</div>


	

	{{-- <div id="gtco-subscribe">
		<div class="gtco-container">
			<div class="row animate-box">
				<div class="col-md-8 col-md-offset-2 text-center gtco-heading">
					<h2>Subscribe</h2>
					<p>Be the first to know about the new templates.</p>
				</div>
			</div>
			<div class="row animate-box">
				<div class="col-md-8 col-md-offset-2">
					<form class="form-inline">
						<div class="col-md-6 col-sm-6">
							<div class="form-group">
								<label for="email" class="sr-only">Email</label>
								<input type="email" class="form-control" id="email" placeholder="Your Email">
							</div>
						</div>
						<div class="col-md-6 col-sm-6">
							<button type="submit" class="btn btn-default btn-block">Subscribe</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div> --}}

	<footer id="gtco-footer" role="contentinfo">
		<div class="gtco-container">
			{{-- <div class="row row-p	b-md">

				<div class="col-md-4">
					<div class="gtco-widget">
						<h3>About Us</h3>
						<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempore eos molestias quod sint ipsum possimus temporibus officia iste perspiciatis consectetur in fugiat repudiandae cum. Totam cupiditate nostrum ut neque ab?</p>
					</div>
				</div>

				<div class="col-md-2 col-md-push-1">
					<div class="gtco-widget">
						<h3>Destination</h3>
						<ul class="gtco-footer-links">
							<li><a href="#">Europe</a></li>
							<li><a href="#">Australia</a></li>
							<li><a href="#">Asia</a></li>
							<li><a href="#">Canada</a></li>
							<li><a href="#">Dubai</a></li>
						</ul>
					</div>
				</div>

				<div class="col-md-2 col-md-push-1">
					<div class="gtco-widget">
						<h3>Hotels</h3>
						<ul class="gtco-footer-links">
							<li><a href="#">Luxe Hotel</a></li>
							<li><a href="#">Italy 5 Star hotel</a></li>
							<li><a href="#">Dubai Hotel</a></li>
							<li><a href="#">Deluxe Hotel</a></li>
							<li><a href="#">BoraBora Hotel</a></li>
						</ul>
					</div>
				</div>

				<div class="col-md-3 col-md-push-1">
					<div class="gtco-widget">
						<h3>Get In Touch</h3>
						<ul class="gtco-quick-contact">
							<li><a href="#"><i class="icon-phone"></i> +1 234 567 890</a></li>
							<li><a href="#"><i class="icon-mail2"></i> info@freehtml5.co</a></li>
							<li><a href="#"><i class="icon-chat"></i> Live Chat</a></li>
						</ul>
					</div>
				</div>

			</div> --}}

			<div class="row copyright">
				<div class="col-md-12">
					<p class="pull-left">
						<small class="block">Copyright &copy; 2019. IYOU All rights reserved.
						</small> 
					</p>
					{{-- <p class="pull-right">
						<ul class="gtco-social-icons pull-right">
							<li><a href="#"><i class="icon-twitter"></i></a></li>
							<li><a href="#"><i class="icon-facebook"></i></a></li>
							<li><a href="#"><i class="icon-linkedin"></i></a></li>
							<li><a href="#"><i class="icon-dribbble"></i></a></li>
						</ul>
					</p> --}}
				</div>
			</div>

		</div>
	</footer>
	<!-- </div> -->

	</div>

	<div class="gototop js-top">
		<a href="#" class="js-gotop"><i class="icon-arrow-up"></i></a>
	</div>
	
	<!-- jQuery -->
	{{-- <script type="text/javascript" src="{{ asset('js/yi/jquery.min.js') }}"></script> --}}
	<script src="js/yi/jquery.min.js"></script>
	<!-- jQuery Easing -->
	{{-- <script type="text/javascript" src="{{ asset('js/yi/jquery.easing.1.3.js') }}"></script> --}}
	<script src="js/yi/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	{{-- <script type="text/javascript" src="{{ asset('js/yi/bootstrap.min.js') }}"></script> --}}
	<script src="js/yi/bootstrap.min.js"></script>
	<!-- Waypoints -->
	{{-- <script type="text/javascript" src="{{ asset('js/yi/jquery.waypoints.min.js') }}"></script> --}}
	<script src="js/yi/jquery.waypoints.min.js"></script>
	<!-- Carousel -->
	{{-- <script type="text/javascript" src="{{ asset('js/yi/owl.carousel.min.js') }}"></script> --}}
	<script src="js/yi/owl.carousel.min.js"></script>
	<!-- countTo -->
	{{-- <script type="text/javascript" src="{{ asset('js/yi/jquery.countTo.js') }}"></script> --}}
	<script src="js/yi/jquery.countTo.js"></script>

	<!-- Stellar Parallax -->
	{{-- <script type="text/javascript" src="{{ asset('js/yi/modernizr-2.6.2.min.js') }}"></script> --}}
	<script src="js/yi/jquery.stellar.min.js"></script>

	<!-- Magnific Popup -->
	{{-- <script type="text/javascript" src="{{ asset('js/yi/jquery.magnific-popup.min.js') }}"></script> --}}
	<script src="js/yi/jquery.magnific-popup.min.js"></script>
	{{-- <script type="text/javascript" src="{{ asset('js/yi/magnific-popup-options.js') }}"></script> --}}
	<script src="js/yi/magnific-popup-options.js"></script>
	
	<!-- Datepicker -->
	{{-- <script type="text/javascript" src="{{ asset('js/yi/bootstrap-datepicker.min.js') }}"></script> --}}
	<script src="js/yi/bootstrap-datepicker.min.js"></script>

	<!-- Main -->
	{{-- <script type="text/javascript" src="{{ asset('js/yi/main.js') }}"></script> --}}
	<script src="js/yi/main.js"></script>

	</body>
</html>

